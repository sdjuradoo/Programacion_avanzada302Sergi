# Conversor de divisas COP - USD

Requisitos: JDK 17+, Maven 3.9+, Apache Tomcat 10.1.x (Jakarta EE 10).

## Ejecutar
1. `mvn clean package` genera `target/conver_divisas_solanojurado.war`.
2. En Eclipse: File > Import > Existing Maven Projects, luego Run on Server (Tomcat 10.1).
3. Abrir http://localhost:8080/conver_divisas_solanojurado/

## Cambiar la tasa (COP por 1 USD)
- Archivo `src/main/resources/tasa.properties` (clave `tasa.usd.cop`), o
- Variable de entorno `TASA_USD_COP` (tiene prioridad sobre el archivo).
