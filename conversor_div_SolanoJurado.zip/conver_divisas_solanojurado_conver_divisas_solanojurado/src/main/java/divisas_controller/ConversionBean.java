package divisas_controller;

import divisas_service.ConversionService;
import divisas_service.HistorialService;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import divisas_model.Conversion;
import divisas_model.Moneda;


@Named("conversionBean")
@ViewScoped
public class ConversionBean implements Serializable {

    private static final long serialVersionUID = 1L;

    @Inject
    private ConversionService conversionService;

    @Inject
    private HistorialService historialService;

    private BigDecimal monto;
    private Moneda origen = Moneda.COP;
    private Moneda destino = Moneda.USD;
    private Conversion resultado;

    public void convertir() {
        try {
            resultado = conversionService.convertir(monto, origen, destino);
            historialService.agregar(resultado);
        } catch (IllegalArgumentException e) {
            resultado = null;
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN, e.getMessage(), null));
        }
    }

 
    public void alCambiarOrigen() {
        destino = origen.contraria();
    }

    public Moneda[] getMonedas() { 
    	return Moneda.values(); 
    	}
    
    public List<Conversion> getHistorial() { 
    	return historialService.getUltimas(); 
    	}
    
    public BigDecimal getTasa() { 
    	return conversionService.getTasa(); 
    	}

    public BigDecimal getMonto() { 
    	return monto; 
    	}
    
    public void setMonto(BigDecimal monto) { 
    	this.monto = monto; 
    	}
    
    public Moneda getOrigen() { 
    	return origen; 
    	}
    
    public void setOrigen(Moneda origen) { 
    	this.origen = origen; 
    	}
    
    public Moneda getDestino() { 
    	return destino; 
    	}
    
    public void setDestino(Moneda destino) { 
    	this.destino = destino; 
    	}
    
    public Conversion getResultado() { 
    	return resultado; 
    	}
    
}
