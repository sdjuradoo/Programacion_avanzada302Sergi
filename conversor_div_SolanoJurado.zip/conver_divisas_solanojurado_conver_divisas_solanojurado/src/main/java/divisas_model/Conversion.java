package divisas_model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;


public class Conversion implements Serializable {

    private static final long serialVersionUID = 1L;

    private final LocalDateTime fecha;
    private final Moneda origen;
    private final Moneda destino;
    private final BigDecimal monto;
    private final BigDecimal resultado;
    private final BigDecimal tasa;

    public Conversion(Moneda origen, Moneda destino, BigDecimal monto,
                      BigDecimal resultado, BigDecimal tasa) {
        this.fecha = LocalDateTime.now();
        this.origen = origen;
        this.destino = destino;
        this.monto = monto;
        this.resultado = resultado;
        this.tasa = tasa;
    }

    public LocalDateTime getFecha() { 
    	return fecha; 
    	}
    
    public Moneda getOrigen() {
    	return origen; 
    	}
    
    public Moneda getDestino() {
    	return destino; 
    	}
    
    public BigDecimal getMonto() { 
    	return monto; 
    	}
    
    public BigDecimal getResultado() { 
    	return resultado;
    	}
    
    public BigDecimal getTasa() {
    	return tasa; 
    	}
}
