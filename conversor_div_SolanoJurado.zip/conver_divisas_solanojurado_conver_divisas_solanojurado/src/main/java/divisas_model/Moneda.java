package divisas_model;


public enum Moneda {
    COP("Peso colombiano (COP)"),
    USD("Dólar estadounidense (USD)");

    private final String etiqueta;

    Moneda(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

   
    public Moneda contraria() {
        return this == COP ? USD : COP;
    }
}
