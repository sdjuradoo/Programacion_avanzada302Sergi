package divisas_repository;

import java.util.List;

import divisas_model.Conversion;

public interface ConversionRepository {

    void guardar(Conversion conversion);

    
    List<Conversion> ultimas(int cantidad);
}
