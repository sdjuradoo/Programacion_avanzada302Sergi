package divisas_repository;

import jakarta.enterprise.context.SessionScoped;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

import divisas_model.Conversion;


@SessionScoped
public class ConversionRepositoryMemoria implements ConversionRepository, Serializable {

    private static final long serialVersionUID = 1L;
    private static final int CAPACIDAD = 50;

    private final LinkedList<Conversion> datos = new LinkedList<>();

    @Override
    public void guardar(Conversion conversion) {
        datos.addFirst(conversion);
        while (datos.size() > CAPACIDAD) {
            datos.removeLast();
        }
    }

    @Override
    public List<Conversion> ultimas(int cantidad) {
        return List.copyOf(datos.subList(0, Math.min(cantidad, datos.size())));
    }
}
