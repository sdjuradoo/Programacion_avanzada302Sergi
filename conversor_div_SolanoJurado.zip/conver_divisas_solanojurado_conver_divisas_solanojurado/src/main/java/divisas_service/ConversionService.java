package divisas_service;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.math.BigDecimal;
import java.math.RoundingMode;

import divisas_model.Conversion;
import divisas_model.Moneda;

/** Logica de negocio de la conversion (sin dependencias de JSF). */
@ApplicationScoped
public class ConversionService {

    @Inject
    private TasaCambioService tasaService;

    public Conversion convertir(BigDecimal monto, Moneda origen, Moneda destino) {
        if (monto == null || monto.signum() <= 0) {
            throw new IllegalArgumentException("El monto debe ser mayor que cero.");
        }
        if (origen == null || destino == null) {
            throw new IllegalArgumentException("Seleccione la divisa de origen y destino.");
        }
        if (origen == destino) {
            throw new IllegalArgumentException("La divisa de origen y destino deben ser distintas.");
        }

        BigDecimal tasa = tasaService.getCopPorUsd();
        BigDecimal resultado = (origen == Moneda.COP)
                ? monto.divide(tasa, 2, RoundingMode.HALF_UP)
                : monto.multiply(tasa).setScale(2, RoundingMode.HALF_UP);

        return new Conversion(origen, destino, monto, resultado, tasa);
    }

    public BigDecimal getTasa() {
        return tasaService.getCopPorUsd();
    }
}
