package divisas_service;

import divisas_repository.ConversionRepository;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

import java.util.List;

import divisas_model.Conversion;

/** Regla de negocio del historial: mostrar solo las ultimas 5 conversiones. */
@ApplicationScoped
public class HistorialService {

    private static final int MAXIMO = 5;

    @Inject
    private ConversionRepository repository;

    public void agregar(Conversion c) {
        repository.guardar(c);
    }

    public List<Conversion> getUltimas() {
        return repository.ultimas(MAXIMO);
    }
}
