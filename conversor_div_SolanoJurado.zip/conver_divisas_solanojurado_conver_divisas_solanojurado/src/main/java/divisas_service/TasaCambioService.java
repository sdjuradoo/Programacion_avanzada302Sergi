package divisas_service;

import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.Properties;

/**
 * Entrega la tasa COP por 1 USD.
 * Prioridad: variable de entorno TASA_USD_COP > archivo tasa.properties.
 */
@ApplicationScoped
public class TasaCambioService {

    static final String ENV_VAR = "TASA_USD_COP";
    static final String PROP_KEY = "tasa.usd.cop";
    static final String ARCHIVO = "tasa.properties";

    private volatile BigDecimal copPorUsd;

    @PostConstruct
    public void recargar() {
        String env = System.getenv(ENV_VAR);
        String valor = env;
        if (valor == null || valor.isBlank()) {
            Properties p = new Properties();
            try (InputStream in = Thread.currentThread()
                    .getContextClassLoader().getResourceAsStream(ARCHIVO)) {
                if (in == null) {
                    throw new IllegalStateException("No se encontro " + ARCHIVO);
                }
                p.load(in);
            } catch (IOException e) {
                throw new IllegalStateException("Error leyendo " + ARCHIVO, e);
            }
            valor = p.getProperty(PROP_KEY);
        }
        BigDecimal tasa = new BigDecimal(valor.trim());
        if (tasa.signum() <= 0) {
            throw new IllegalStateException("La tasa debe ser mayor que cero");
        }
        this.copPorUsd = tasa;
    }

    public BigDecimal getCopPorUsd() {
        return copPorUsd;
    }
}
